# Task Scheduler
Is an Android application able to manage personal tasks within a calendar, send notifications, modify tasks, mark them as completed or postpone them.
### Installation
1. [Download the APK file on your phone](https://drive.google.com/open?id=1vTIr-iJNwXaVDMILinjTje_K51gb0a7_)
2. Enable 'Allow Installation from Unknown Sources' in Settings
3. Install
### Requirements
Android 5.0

### Screenshots
<img src="https://i.postimg.cc/MTWLTNpf/Screenshot-1569410478.png" 
    height="500" style="display: block;margin-left: auto;margin-right: auto;">
    
<img src="https://i.postimg.cc/rFSY1qRR/Screenshot-1569410467.png" 
    height="500" style="display: block;margin-left: auto;margin-right: auto;">
